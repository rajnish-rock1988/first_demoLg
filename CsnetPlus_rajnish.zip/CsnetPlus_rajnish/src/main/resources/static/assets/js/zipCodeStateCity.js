$(document).ready(function(){
	//alert("hii");

  $('#zipCode').bind('blur', function () {
	var zipCode = $("#zipCode").val();
	//alert("hii--zipcode1--"+ zipCode );
	
	if(!zipCode){
		//alert("null value");
		return false;
		}
		if(zipCode.length < 6){
		alert("ZipCode will be 6 Digit!");
		return false;
		}
		if(zipCode.length > 6){
		alert("ZipCode Will Be 6 Digit!");
		return false;
		}
	 
					$.ajax({
						type : "GET",
						url : 'zipCodegetAll/' + zipCode,
						
						contentType : "application/json",
						success : function(response) {
						//	$('#state').html("");
							if(response == "You Have Entered Wrong Zip Code"){
							alert( response);
							}else{
							//	alert( response);
								$("#state").html(response);
								            var options = "";
            						// for (var i = 0; i < response.length; i++) {
                 						options += "<option>" +response + "</option>";
                 						// }
             								$("#state").html(options);

							}
							
						},
						error : function(result) {
							 alert(zipCode + "   Zip Code Not Found" );
						}
					});
		
			
	});
	
 $("#state").click(function(){
        var zipCode = $("#zipCode").val();
        var stateName = $("#state").val();
    
       if(!zipCode ){
				alert("Enter  Zip Code first  ");
				return false;
      }
      
    
        $.ajax({
						type : "GET",
						url : 'getCityFromState',
						data:{"zipCode": zipCode,"stateName": stateName},
						contentType : "application/json",
						success : function(response) {
		
							if(response == "You have entered wrong pin!"){
							alert( response);
							}else{
								$("#city").html(response);
								            var options = "";
            						// for (var i = 0; i < response.length; i++) {
                 						options += "<option>" +response + "</option>";
                 						// }
             								$("#city").html(options);

							}
							
						},
						error : function(result) {
							 alert("   Please Select Correct State or Zip Code" );
						}
					});
					  
    });	
    
    
 $("#city").click(function(){
	   var zipCode = $("#zipCode").val();
        var stateName = $("#state").val();
    
       if(!zipCode ){
				alert("Enter  ZipCode And Select State Name  ");
				return false;
      }
         if(!stateName ){
				alert("Select State Name first  ");
				return false;
      }
	
	});	

$('#loginId').bind('blur', function () {
	var loginId = $("#loginId").val();
	//alert("hii--loginId--"+ loginId );
	
	
	 
					$.ajax({
						type : "GET",
						url : 'checkDuplicateLoginId/' + loginId,
						
						contentType : "application/json",
						success : function(response) {
						if(response == "Already Registered!")
							{
								alert( response);
								}
						
							
						},
						error : function(result) {
							// alert( " SomeThing Went Wrong!" );
						}
					});
		
			
	});

    
    
	
	});