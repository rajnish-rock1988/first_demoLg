$(document).ready(function(){
	

 
	
	$('#firstName').bind('blur', function () {
	$(this).val($(this).val().toUpperCase());
	});
	
	$('#lastName').bind('blur', function () {
	$(this).val($(this).val().toUpperCase());
	});
	
	$('#emailId').bind('blur', function () {
	$(this).val($(this).val().toUpperCase());
	var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
	
	var emailId = $("#emailId").val();
	if(emailId.match(mailformat)){
     
		//document.form1.text1.focus();
		return true;
	}else{
		alert("You have entered an invalid email address!");
		//document.form1.text1.focus();
		return false;
	}


	});
		});
