$(document).ready(function(){
	
/*	// Get the container element
var btnContainer = document.getElementById("asideMenu");

// Get all buttons with class="btn" inside the container
var btns = btnContainer.getElementsByClassName("nav-item");

// Loop through the buttons and add the active class to the current/clicked button
for (var i = 0; i < btns.length; i++) {
  btns[i].addEventListener("click", function() {
    var current = document.getElementsByClassName("active");
    current[0].className = current[0].className.replace(" active", "");
    this.className += " active";
  });
}
*/	
	
	
	
	var btns = document.querySelectorAll(".nav-link");
	
   Array.from(btns).forEach(item => {
      item.addEventListener("click", () => {
         var selected = document.getElementsByClassName("active");
         selected[0].className = selected[0].className.replace(" active", "");
         item.className += " active";
      });
   });
	
	/*
	$(".nav-item").on('click', 'li', function(e) {
    $('#dashboard').parent().find('li.active').removeClass('active');
    $('#dashboard').addClass('active');
});*/

});

///////////////////////////////////////////////////////////////////////////////

/*$(document).ready(function () {
       // var rolval = " ";
       // $('#ddlRole').val(rolval);
        $('#nav-item').attr("style", "color:#ff9933; font-weight:bold;");
      $('#nav-item').addClass('active');
    });*/