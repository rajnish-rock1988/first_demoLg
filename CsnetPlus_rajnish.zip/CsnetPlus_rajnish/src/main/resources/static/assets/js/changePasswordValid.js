$(document).ready(function(){
 
  
        $("#btnSubmit").click(function () {
        	var oldPassword = $("#oldPassword").val();
            var newPassword = $("#newPassword").val();
            var confirmPassword = $("#confirmPassword").val();
            var format = /^(lg|LG)/;
            var month = /(jan|feb|mar|apr|may|jun|jul|aug|sept|oct|nov|dec)/i;
            var date=new Date();
            var currentYear=date.getFullYear();
            var regex1=/([a-zA-Z0-9])\1{2,}/

        	  
        	  
        	  if(newPassword.match(regex1)){
              	alert("In New Password 3 sequence of character and Number are not allowed");
              	return false;
              }
               if(confirmPassword.match(regex1)){
              	alert("In Confirm Password 3 sequence of character and Number are not allowed");
              	return false;
              }
           /* if(newPassword.length>4){
    			alert("New Password will not be more than 4 Character");	
    			return false;
    	    }
            if(confirmPassword.length>4){
    			alert("Confirm Password will not be more than 4 Character");	
    			return false;
    	    }*/
            if(newPassword.match(format)){
            	alert("New Password can't be start with lg/LG");
            	return false;
            }
             if(confirmPassword.match(format)){
            	alert("Confirm Password can't be start with lg/LG");
            	return false;
            }
             if(newPassword.match(month)){
             	alert("Month can not be used in New Password");
             	return false;
             }
              if(confirmPassword.match(month)){
             	alert("Month can not be used in Current Password");
             	return false;
             }
              if(newPassword == currentYear){
              	alert("Current Year can't used as Current Password");
              	return false;
              }
               if(confirmPassword == currentYear){
              	alert("Current Year can't used as Confirm Password");
              	return false;
              }
               if(newPassword == currentYear-1){
               	alert("Previous Year can't used as New Password");
               	return false;
               }
                if(confirmPassword == currentYear-1){
               	alert("previous year can not be used as Confirm password");
               	return false;
               }
            if (newPassword == oldPassword) {
                alert("Old Password and New Password should not be same");
                return false;
            }
            if (newPassword != confirmPassword) {
                alert("New Password and Confirm Password are not same");
                return false;
            }
             if (newPassword == confirmPassword) {
            //    alert("Password Has been Changed Successfully!");
                return true;
            }
            /*if (loginId == currentPassword) {
                alert("LoginId and Current Password should not be same");
                return false;
            }
            if (loginId == newPassword) {
                alert("LoginId and New Password should not be same");
                return false;
            }*/
            
                 
            
            return true;   
        });
        
      

    });
    
    
    
    $("body").on('click', '.toggle-password', function() {
  $(this).toggleClass("fa-eye fa-eye-slash");
  var input = $("#oldPassword");
 // var input = $("#oldPassword").val();
 // alert("tog" + input);
  if (input.attr("type") === "password") {
    input.attr("type", "text");
  } else {
    input.attr("type", "password");
  }

});

    $("body").on('click', '.toggle-newPassword', function() {
  $(this).toggleClass("fa-eye fa-eye-slash");
  var input = $("#newPassword");
  //alert("tog" + input);
  if (input.attr("type") === "password") {
    input.attr("type", "text");
  } else {
    input.attr("type", "password");
  }

});
    $("body").on('click', '.toggle-confirmPassword', function() {
  $(this).toggleClass("fa-eye fa-eye-slash");
  var input = $("#confirmPassword");
  //alert("tog" + input);
  if (input.attr("type") === "password") {
    input.attr("type", "text");
  } else {
    input.attr("type", "password");
  }

});