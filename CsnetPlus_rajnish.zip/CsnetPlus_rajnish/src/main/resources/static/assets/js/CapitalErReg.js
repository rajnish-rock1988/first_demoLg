$(document).ready(function(){
	//alert("hi");

 $('#employeeId').bind('blur', function () {
	var employeeId = $("#employeeId").val();
	if(employeeId.length < 5){
		alert("Length of Employee Id Should be 5 - 30 Character")
		return false;
	}if(employeeId.length > 30){
		alert("Length of Employee Id Should not be more than 30 Character")
		return false;
	}
	$(this).val($(this).val().toUpperCase());
	return true;
	});
	
	$('#branch').bind('blur', function () {
	$(this).val($(this).val().toUpperCase());
	});
	
	$('#asc').bind('blur', function () {
	$(this).val($(this).val().toUpperCase());
	});
	
	$('#companyId').bind('blur', function () {
	$(this).val($(this).val().toUpperCase());
	});
	
	$('#mobileNumber').bind('blur', function () {
	var mobileNo = $("#mobileNumber").val();
	//alert("Mobile No is-- " + mobileNo);
	if(mobileNo.length < 10){
		alert("Mobile No. Should be 10 Digit")
		return false;
		}
		if(mobileNo.length >10){
		alert("Mobile No. Should Not be Greater than 10 Digit")
		return false;
		}
	});
	
	$('#aadharNo').bind('blur', function () {
	var adharNum = $("#aadharNo").val();
	//alert("Mobile No is-- " + mobileNo);
	if(adharNum.length < 12){
		alert("Aadhaar  No. Should be 12 Digit")
		return false;
		}
	if(adharNum.length >12){
		alert("Aadhaar No. Should Not be Greater than 12 Digit")
		return false;
		}
	});
	
	$('#shiftToCode').bind('blur', function () {
	$(this).val($(this).val().toUpperCase());
	});
	
	$('#firstName').bind('blur', function () {
	$(this).val($(this).val().toUpperCase());
	});
	
	/*-----*/
	
	$('#middleName').bind('blur', function () {
	$(this).val($(this).val().toUpperCase());
	});
	$('#lastName').bind('blur', function () {
	$(this).val($(this).val().toUpperCase());
	});
	$('#currentAddress').bind('blur', function () {
	$(this).val($(this).val().toUpperCase());
	});
	$('#permanatAddress').bind('blur', function () {
	$(this).val($(this).val().toUpperCase());
	});
	$('#aadharNo').bind('blur', function () {
	$(this).val($(this).val().toUpperCase());
	});
	$('#exp1NameOfCompany').bind('blur', function () {
	$(this).val($(this).val().toUpperCase());
	});
	$('#exp1FirmNameAndCity').bind('blur', function () {
	$(this).val($(this).val().toUpperCase());
	});
	$('#exp2NameOfCompany').bind('blur', function () {
	$(this).val($(this).val().toUpperCase());
	});
	$('#exp2FirmNameAndCity').bind('blur', function () {
	$(this).val($(this).val().toUpperCase());
	});
	$('#exp3NameOfCompany').bind('blur', function () {
	$(this).val($(this).val().toUpperCase());
	});
	
	$('#exp3FirmNameAndCity').bind('blur', function () {
	$(this).val($(this).val().toUpperCase());
	});
	
	$('#otherQualification').bind('blur', function () {
	$(this).val($(this).val().toUpperCase());
	});
	
	$('#nomineeName').bind('blur', function () {
	$(this).val($(this).val().toUpperCase());
	});
	$('#salaryInHand').bind('blur', function () {
	$(this).val($(this).val().toUpperCase());
	});
	$('#incentive').bind('blur', function () {
	$(this).val($(this).val().toUpperCase());
	});
	$('#mobileCharges').bind('blur', function () {
	$(this).val($(this).val().toUpperCase());
	});
	$('#lastSalaryPaidByAsc').bind('blur', function () {
	$(this).val($(this).val().toUpperCase());
	});
	
	/*-----*/
	
	$('#emailId').bind('blur', function () {
	$(this).val($(this).val().toUpperCase());
	var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
	
	var emailId = $("#emailId").val();
	if(emailId.match(mailformat)){
     
		//document.form1.text1.focus();
		return true;
	}else{
		alert("You have entered an invalid email address!");
		//document.form1.text1.focus();
		return false;
	}


	});
	
	
	
	});
	
	