$(document).ready(function(){
	
	$('#EmpIdAR').click(function(){
			/*alert("hi testing on change");*/
			var selectedEmpIdAR=$(this).val();
         /*alert("selectedEmpIdAR --" + selectedEmpIdAR);*/
       $.ajax({
						contentType : "application/json; charset=utf-8",
						type : "GET",
						url : 'getEmpIdInformation',
						dataType:'json',
						data:{"selectedEmpIdAR": selectedEmpIdAR},
						success : function(response) { 
						 
							const ddd= JSON.parse(JSON.stringify(response));
                               /*alert(ddd[0].empId);*/
                               $("#employeeId").val(ddd[0].empId);
                              // $("#employeeCreationDate").val(ddd[0].creationDate);
                                              
                               $("#branch").val(ddd[0].branch);
                               $("#companyId").val(ddd[0].companyId);
                               $("#sTc").val(ddd[0].shiftToCode);
                               $("#fName").val(ddd[0].firstName);
                               $("#mName").val(ddd[0].middleName);
                               $("#lName").val(ddd[0].lastName);
                               $("#designation").val(ddd[0].designation);
                               $("#cAddr").val(ddd[0].currentAddress);
                               $("#pAddr").val(ddd[0].permanatAddress);
                               $("#dob").val(ddd[0].dateOfBirth);
                               $("#mobNo").val(ddd[0].mobileNumber);
                               $("#telNo").val(ddd[0].telephoneNumber);
                               $("#state").val(ddd[0].state);
                               $("#aadharNo").val(ddd[0].aadharNo);
                               $("#eng_resume").val(ddd[0].eng_resume);
                               $("#eng_photo").val(ddd[0].eng_photo);
                               $("#eng_adhar").val(ddd[0].eng_adhar);
                               $("#eng_qualification").val(ddd[0].eng_qualification);
                               $("#city").val(ddd[0].city);
                               $("#gender").val(ddd[0].gender);
                               $("#eMail").val(ddd[0].emailId);
                               $("#lgJDate").val(ddd[0].lgJoinDate);
                               $("#exp1Type").val(ddd[0].exp1Type);
                               $("#exp1CN").val(ddd[0].exp1NameOfCompany);
                               $("#exp1FC").val(ddd[0].exp1FirmNameAndCity);
                               $("#exp1FromD").val(ddd[0].exp1FromDate);
                               $("#exp1ToD").val(ddd[0].exp1ToDate);
                               $("#exp2Type").val(ddd[0].exp2Type);
                               $("#exp2CN").val(ddd[0].exp2NameOfCompany);
                               $("#exp2FC").val(ddd[0].exp2FirmNameAndCity);
                               $("#exp2FromD").val(ddd[0].exp2FromDate);
                               $("#exp2ToD").val(ddd[0].exp2ToDate);
                               $("#exp3Type").val(ddd[0].exp3Type);
                               $("#exp3CN").val(ddd[0].exp3NameOfCompany);
                               $("#exp3FC").val(ddd[0].exp3FirmNameAndCity);
                               $("#exp3FromD").val(ddd[0].exp3FromDate);
                               $("#exp3ToD").val(ddd[0].exp3ToDate);
                               $("#bQualififcation").val(ddd[0].basicQualification);
                               $("#othQualification").val(ddd[0].otherQualification);
                               $("#nomineeName").val(ddd[0].nomineeName);
                               $("#relationEmp").val(ddd[0].relationWtihEmployee);
                               $("#salaryHand").val(ddd[0].salaryInHand);
                               $("#incentive").val(ddd[0].incentive);
                               $("#convenyanceType").val(ddd[0].conveyanceType);
                               $("#convenRate").val(ddd[0].conveyanceRate);
                               $("#espy").val(ddd[0].espy);
                               $("#asc").val(ddd[0].asc);
                               $("#ascType").val(ddd[0].ascType);
                               //alert(ddd[0].espy);
                               $("#mobileCharges").val(ddd[0].mobileCharges);
                               $("#incentiveDate").val(ddd[0].lastIncentive);
                               $("#lastSalaryPaidByAsc").val(ddd[0].lastSalaryPaidByAsc);
                               //alert("last asc paid"+ddd[0].lastSalaryPaidByAsc);
                               $("#engStatus").val(ddd[0].engStatus);
                               var resumedownload = '/resumeDownloadDocument/';
                               var photodownload = '/photoDownloadDocument/';
                               var adharDownload = '/adharDownloadDocument/';
                               var qualifiDownload = '/qualifiDownloadDocument/';
                               const empId= ddd[0].empId;
                               resumedownload= resumedownload+empId;
                               qualifiDownload= qualifiDownload+empId;
                               adharDownload= adharDownload+empId;
                               photodownload= photodownload+empId;
                               /*alert("link----------"+resumedownload);*/
                                $("#resumeDownload").attr('href',resumedownload);
                                $("#photodownload").attr('href',photodownload);
                                $("#adharDownload").attr('href',adharDownload);
                                $("#qualifiDownload").attr('href',qualifiDownload);
                               
                               
							   //alert(ddd[0].firstName);
							  // alert(ddd[0].branch);
							
										
				},
						error : function(result) {
							 alert("Please select a valid employee" );
						}
					}); 
     
			});
});			
