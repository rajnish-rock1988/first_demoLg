$(document).ready(function(){
	

 $('#loginId').bind('blur', function () {
	var loginId = $("#loginId").val();
	if(!loginId ){
				//alert("Select State Name first  ");
				return false;
      }
	
	if(loginId.length < 5){
		alert("Length of Login Id Should be 5 - 30 Character")
		return false;
	}if(loginId.length > 30){
		alert("Length of Login Id Should not be more than 30 Character")
		return false;
	}
	
	
	$(this).val($(this).val().toUpperCase());
	return true;
	});
	
	$('#firstName').bind('blur', function () {
	$(this).val($(this).val().toUpperCase());
	});
	
	$('#lastName').bind('blur', function () {
	$(this).val($(this).val().toUpperCase());
	});
	
	$('#mobileNo').bind('blur', function () {
	var mobileNo = $("#mobileNo").val();
	//alert("Mobile No is-- " + mobileNo);
	
	if(!mobileNo){
		//alert("null value");
		return false;
		}
	if(mobileNo.length < 10){
		alert("Mobile No. Should be 10 Digit");
		return false;
		}
		if(mobileNo.length >10){
		alert("Mobile No. Should Not be Greater than 10 Digit");
		return false;
		}
		
	});
	
	$('#address1').bind('blur', function () {
	$(this).val($(this).val().toUpperCase());
	});
	
	$('#address2').bind('blur', function () {
	$(this).val($(this).val().toUpperCase());
	});
	
	$('#emailId').bind('blur', function () {
	$(this).val($(this).val().toUpperCase());
	var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
	
	var emailId = $("#emailId").val();
	if(!emailId){
		return false;
	}
	
	if(emailId.match(mailformat)){
     
		return true;
	}else{
		alert("You have entered an invalid email address!");
		return false;
	}


	});
	
	
	
	});
	
	