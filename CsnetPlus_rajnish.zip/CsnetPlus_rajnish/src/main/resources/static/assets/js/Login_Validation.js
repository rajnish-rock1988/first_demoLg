$(document).ready(function(){
  
        $("#loginIdBtn").click(function () {
        	var userName = $("#loginId").val();
            var password = $("#passwordId").val();
           
            var format = /^(lg|LG)/;
            var month = /(jan|feb|mar|apr|may|jun|jul|aug|sept|oct|nov|dec)/i;
            var date=new Date();
            var currentYear=date.getFullYear();
          var regex1=/([a-zA-Z0-9])\1{2,}/;
          //var regex2 = /^[a-zA-Z0-9!@#\$%\^\&*\)\(+=._-]{2,}$/g;
          

                
            
            if(password.length>10){
    			alert("Length of Password should not be more than 10 Character");	
    			return false;
    	}
         
            if (userName == password) {
                alert("Username and Password should not be same");
                return false;
            }
            
            
             if(password == currentYear){
            	alert("Current Year can't used as Password");
            	return false;
            }
            
             if(password == currentYear-1){
            	alert("Previous Year can't used as Password");
            	return false;
            }
             
             if(password.match(format)){
			
            	alert("LG/lg can not use in Password");
            	return false;
            }
             
             if(password.match(month)){
            	alert("month can not be used in password");
            	return false;
            }
             
          /*  if(password.match(regex1)){
            	alert("3 sequence character and Character not allowed");
            	return false;
            }*/
            
            /*if(userName.match(regex2)){
				alert("Login Id should not contain special character and minimum length should be 4");
				return false;
			}*/
             
                    
            
            return true;   
        });

    });