$(document).ready(function(){
	
$("#stateErReg").change(function(){

        var stateName = $("#stateErReg").val();
       // alert("StateName "+stateName);
     //   $(this).val($(this).val().toUpperCase());
       // alert("zip code--" + zipCode + "stateName--" + stateName);
       if(stateName == null){
				//alert("Enter state name" );
      }  
        $.ajax({
						type : "GET",
						url : 'getCitiesFromState',
						data:{"stateName": stateName},
						contentType : "application/json; charset=utf-8",
						success : function(response) {
							//alert("in response---" + response);
							//var ddd= JSON.parse(JSON.stringify(response));
							
								//$("#city").html(response);
								            var options = "";
            						for (var i = 0; i < response.length; i++) {
                 						options += "<option>" +response[i] + "</option>";
                 						 }
             								$("#cityErReg").html(options);
							
						},
						error : function(result) {
							 alert("   Please Select Correct State" );
						}
					});       
    });
    
    
    $('#mobileNumber').bind('blur', function () {
	var mobileNo = $("#mobileNumber").val();
	//alert("Mobile No is-- " + mobileNo);
	if(mobileNo.length <10){
		alert("Mobile No. Should be 10 Digit")
		return false;
		}
		if(mobileNo.length >10){
		alert("Mobile No. Should Not be Greater than 10 Digit")
		return false;
		}
	});
    
    
    });