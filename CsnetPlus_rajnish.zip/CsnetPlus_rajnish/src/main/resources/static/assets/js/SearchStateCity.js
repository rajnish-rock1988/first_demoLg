$(document).ready(function(){
	
	//alert("test");
	
  //-------------------------
  
  $('#searchRole').click(function(){
	//alert("now in role");
	var selected_val = $('#searchRole :selected').text();
	
/*	$.ajax({
						type : "GET",
						url : 'getSearchRole',
						//data:{"selectedState": selectedState},
						contentType : "application/json",
						success : function(response) {
		
						//	alert("response : " + response);
							 var options = "<select class=form-control + name=role + id=searchRole>";
            						for (var i = 0; i < response.length; i++) {     
                                             options += "<option value="+i+ "   >"   +response[i] + "</option>";
										
                 						 }
                 						 
                 						   options +=  "</select>";
             								$("#test").html(options);
             													
							
						},
						error : function(result) {
							 alert("   Please Select State Name" + result );
						}
					});  */

	});

  
  
  
  
  
  //-------------------
	
	
	
	$('#stateSearch').click(function(){
	//alert("now in state");
	/*$.ajax({
						type : "GET",
						url : 'getCityNameNew',
						//data:{"selectedState": selectedState},
						contentType : "application/json",
						success : function(response) {
		
							//alert("response : " + response);
							  var options = "";
            						for (var i = 0; i < response.length; i++) {
                 						options += "<option>" +response[i] + "</option>";
                 						 }
             								$("#stateSearch").html(options);
             													
							
						},
						error : function(result) {
							 alert("   Please Select State Name" + result );
						}
					});*/

	});
	
	$('#stateSearch').change(function(){
	//	$("#stateSearch").click(function(){
		 // $('#state').bind('change', function () {
			
			var selectedState=$(this).val();
    // alert("selectedState --" + selectedState);
  
 
  $.ajax({
						type : "GET",
						url : 'getCityNameSearch',
						data:{"selectedState": selectedState},
						contentType : "application/json",
						success : function(response) {
		
							
							//alert( response);
							//alert("response length is--" + response.length);
							
							//	$("#searchCity").html(response);
								            var options = "";
            						 for (var i = 0; i < response.length; i++) {
                 						options += "<option>" +response[i] + "</option>";
                 						$("#searchCity").html(options);
                 						 }
             								//$("#searchCity").html(options);
             													
							
						},
						error : function(result) {
							 alert("   Please Select State Name" );
						}
					});

 
 
});

	$('#searchCity').click(function(){
	var city = $("#searchCity").val();
        var state = $("#stateSearch").val();
        
        //alert("city--  " + city + "state-- " + state);
        if(state ==1){
			alert("Select State! ");
			return(false); 
    	}


});
//--------used update search engineer

$('#updateEngineer').click(function(){
			alert("hi testing on change");
			var selectedEmpIdAR=$(this).val();
         alert("updateEngineer --" + selectedEmpIdAR);
       $.ajax({
						contentType : "application/json; charset=utf-8",
						type : "GET",
						url : 'getEmpIdInformation',
						dataType:'json',
						data:{"selectedEmpIdAR": selectedEmpIdAR},
						success : function(response) { 
						 
							const ddd= JSON.parse(JSON.stringify(response));
                               /*alert(ddd[0].empId);*/
                               $("#employeeId").val(ddd[0].empId);
                              // $("#employeeCreationDate").val(ddd[0].creationDate);
                                              
                               $("#branch").val(ddd[0].branch);
                               $("#companyId").val(ddd[0].companyId);
                               $("#sTc").val(ddd[0].shiftToCode);
                               $("#fName").val(ddd[0].firstName);
                               $("#mName").val(ddd[0].middleName);
                               $("#lName").val(ddd[0].lastName);
                               $("#designation").val(ddd[0].designation);
                               $("#cAddr").val(ddd[0].currentAddress);
                               $("#pAddr").val(ddd[0].permanatAddress);
                               $("#dob").val(ddd[0].dateOfBirth);
                               $("#mobNo").val(ddd[0].mobileNumber);
                               $("#telNo").val(ddd[0].telephoneNumber);
                               $("#state").val(ddd[0].state);
                               $("#aadharNo").val(ddd[0].aadharNo);
                               $("#eng_resume").val(ddd[0].eng_resume);
                               $("#eng_photo").val(ddd[0].eng_photo);
                               $("#eng_adhar").val(ddd[0].eng_adhar);
                               $("#eng_qualification").val(ddd[0].eng_qualification);
                               $("#city").val(ddd[0].city);
                               $("#gender").val(ddd[0].gender);
                               $("#eMail").val(ddd[0].emailId);
                               $("#lgJDate").val(ddd[0].lgJoinDate);
                               $("#exp1Type").val(ddd[0].exp1Type);
                               $("#exp1CN").val(ddd[0].exp1NameOfCompany);
                               $("#exp1FC").val(ddd[0].exp1FirmNameAndCity);
                               $("#exp1FromD").val(ddd[0].exp1FromDate);
                               $("#exp1ToD").val(ddd[0].exp1ToDate);
                               $("#exp2Type").val(ddd[0].exp2Type);
                               $("#exp2CN").val(ddd[0].exp2NameOfCompany);
                               $("#exp2FC").val(ddd[0].exp2FirmNameAndCity);
                               $("#exp2FromD").val(ddd[0].exp2FromDate);
                               $("#exp2ToD").val(ddd[0].exp2ToDate);
                               $("#exp3Type").val(ddd[0].exp3Type);
                               $("#exp3CN").val(ddd[0].exp3NameOfCompany);
                               $("#exp3FC").val(ddd[0].exp3FirmNameAndCity);
                               $("#exp3FromD").val(ddd[0].exp3FromDate);
                               $("#exp3ToD").val(ddd[0].exp3ToDate);
                               $("#bQualififcation").val(ddd[0].basicQualification);
                               $("#othQualification").val(ddd[0].otherQualification);
                               $("#nomineeName").val(ddd[0].nomineeName);
                               $("#relationEmp").val(ddd[0].relationWtihEmployee);
                               $("#salaryHand").val(ddd[0].salaryInHand);
                               $("#incentive").val(ddd[0].incentive);
                               $("#convenyanceType").val(ddd[0].conveyanceType);
                               $("#convenRate").val(ddd[0].conveyanceRate);
                               $("#espy").val(ddd[0].espy);
                               $("#asc").val(ddd[0].asc);
                               $("#ascType").val(ddd[0].ascType);
                               //alert(ddd[0].espy);
                               $("#mobileCharges").val(ddd[0].mobileCharges);
                               $("#incentiveDate").val(ddd[0].lastIncentive);
                               $("#lastSalaryPaidByAsc").val(ddd[0].lastSalaryPaidByAsc);
                               //alert("last asc paid"+ddd[0].lastSalaryPaidByAsc);
                               $("#engStatus").val(ddd[0].engStatus);
                               var resumedownload = '/resumeDownloadDocument/';
                               var photodownload = '/photoDownloadDocument/';
                               var adharDownload = '/adharDownloadDocument/';
                               var qualifiDownload = '/qualifiDownloadDocument/';
                               const empId= ddd[0].empId;
                               resumedownload= resumedownload+empId;
                               qualifiDownload= qualifiDownload+empId;
                               adharDownload= adharDownload+empId;
                               photodownload= photodownload+empId;
                               /*alert("link----------"+resumedownload);*/
                                $("#resumeDownload").attr('href',resumedownload);
                                $("#photodownload").attr('href',photodownload);
                                $("#adharDownload").attr('href',adharDownload);
                                $("#qualifiDownload").attr('href',qualifiDownload);
                               
                               
							   //alert(ddd[0].firstName);
							  // alert(ddd[0].branch);
							
										
				},
						error : function(result) {
							 alert("Please select a valid engineer employee " );
						}
					}); 
     
			});



//-----------------------download
$("#downloadBtn").click(function(){
        var firstName = $("#firstName").val();
        
        var lastName = $("#lastName").val();
        var emailId = $("#emailId").val();
        var mobileNo = $("#mobileNo").val();
        var role = $("#searchRole").val();
        var state = $("#stateSearch").val();
         var city = $("#searchCity").val();
    
    
      
    
        $.ajax({
						type : "GET",
						url : 'downloadUSerDetails',
						data:{"firstName": firstName,"lastName": lastName,"emailId": emailId ,"mobileNo": mobileNo ,
						"role": role, "state": state, "city": city},
						contentType : "applcation/octet-stream",
						//responseType: 'blob',
						success : function(response) {
		
							alert("response" + response);
							
							//$("#downloadBtn").attr('href',qualifiDownload);

							
							
						},
						error : function(result) {
							 alert("   Something Went Wrong! " );
						}
					});
					  
    });	
    
 //----------
 $("#SearchBtnDownload").click(function(){   

	alert("Click on Search User!");
	return false;

});

});
