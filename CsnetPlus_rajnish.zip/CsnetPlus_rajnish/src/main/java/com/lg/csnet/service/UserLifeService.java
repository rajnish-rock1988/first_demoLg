package com.lg.csnet.service;

import java.util.List;

import com.lg.csnet.entity.UserLg;
import com.lg.csnet.repository.UserLifeRepository;


public interface UserLifeService {
	
	
	 // public static final UserLifeRepository userLifeRepository = null;
	
	public static final UserLifeRepository userLifeRepository = null;
	  
	  public void saveUser(UserLg Userlg);
	  
	  public static Object getAllUserSearch() {
			
			return (List<UserLg>) userLifeRepository.findAll();
		}
		
		public static List<UserLg> findById(String id) {
			return userLifeRepository.findById(id);
		}
	  
	  
		public  String updateUser(UserLg userlg);
		
	
	
}