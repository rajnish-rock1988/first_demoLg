package com.lg.csnet.controller;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

//import java.util.ArrayList;
//import java.util.Arrays;
//import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.lg.csnet.entity.CsnCodeMaster;
import com.lg.csnet.entity.StateCityDropDown;




@Controller
public class MainController {
	
	
	
		
		
	@GetMapping("/resign")
	public String resignEmployee(Model m) {
		return "resign"; 
	}
	
	
	// @GetMapping("/register")
/*	@GetMapping("/createUser")
	public String showForm(Model model) {
		
		System.out.println("get user group in drop down------");
		int uglookupcode=2;
		List<CsnCodeMaster> userGroup = CsnCodeMasterService.getUserGroup(uglookupcode);  // fetch lookup code from db use in dropdown value
		System.out.println("user group--" + userGroup);
		 ArrayList<String> list=new ArrayList<String>();//Creating arraylist
		for(CsnCodeMaster ugr : userGroup) {
			list.add(ugr.getLookupType());
		}
		model.addAttribute("lookupType",list);
		
		System.out.println("get company detail in drop down------");
		int companyLookupcode=3;
		List<CsnCodeMaster> company2 = CsnCodeMasterService.getCompany(companyLookupcode);
		 ArrayList<String> companyList=new ArrayList<String>();
		 for(CsnCodeMaster compdetail : company2) {
			 companyList.add(compdetail.getLookupType());
			 System.out.println(compdetail.getLookupType());
		 }
		 model.addAttribute("companyList",companyList);
		 
		 System.out.println("get role detail in drop down------");
			int roleLookupcode=4;
			List<CsnCodeMaster> role = CsnCodeMasterService.getRole(roleLookupcode);
			 ArrayList<String> roleList=new ArrayList<String>();
			 for(CsnCodeMaster roleDetail : role) {
				 roleList.add(roleDetail.getLookupType());
				 System.out.println(roleDetail.getLookupType());
			 }
			 model.addAttribute("roleList",roleList);
		 
		System.out.println("now in main controller creat user");
				return "createUser";
	} */
	
	
	

	@GetMapping("/dashboard")
	public String showDashboard(Model model,HttpServletRequest request) {
		//Session Check
				HttpSession session= request.getSession();
				String sessloginId = (String) session.getAttribute("loginId");
				String sessGetStatus = (String) session.getAttribute("status");
				if(sessloginId != null && sessGetStatus.equals("OLD") ) {
		return "dashboard";}
				else {
					model.addAttribute("error","Session Expired! Please Login");
					return "loginForm";
				}
	}

		
		@GetMapping("/changePassword")
		public String showChangePassword(Model model, HttpSession session) {
			
			//Session Check
			String sessloginId = (String) session.getAttribute("loginId");
			String sessGetStatus = (String) session.getAttribute("status");
			if(sessloginId != null && sessGetStatus.equals("OLD") ) {
			
			System.out.println("test----------");
			
			String loginId = (String) session.getAttribute("loginId");
			System.out.println("checking session id---");
			System.out.println("****** login id from session *****" + loginId);
			
			String getStatus = (String) session.getAttribute("status");
			System.out.println("****** STATUS from session *****--" + getStatus);
			//return "changePassword";
			}
			return "changePassword";
			/*else {
				model.addAttribute("error","Session Expired! Please Login");
				return "loginForm";
			}*/
		}
		
		

		
		@GetMapping("/master")
		public String checkMaster(Model model) {
			System.out.println("now in master");
			return "master";
		}
		
		
		
		
		
		
		

	
	
}
