package com.lg.csnet.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="MASTER_ENTRY")
public class MasterEntry {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="ID")
	private Long id;
	
	@Column(name="LOOKUP_CODE")
	private String lookupCode;
	
	@Column(name="LOOKUP_TYPE")
	private String lookupType;
	
	@Column(name="VALUE")
	private String value;
	
	@Column(name="DESCRIPTION")
	private String description;
		
	@Column(name="CREATED_BY")
	private String createdBy;
	
	@Column(name="CREATED_ON")
	private Date createdOn;
	
	@Column(name="MODIFIED_BY")
	private String modifiedBy;
	
	@Column(name="ATTRIBUTE1")
	private String attribute1;
	
	@Column(name="ATTRIBUTE2")
	private String attribute2;
	
	@Column(name="ATTRIBUTE3")
	private String attribute3;
	
	@Column(name="ATTRIBUTE4")
	private Integer attribute4;
	
	
	@Column(name="ATTRIBUTE5")
	private Integer attribute5;
	
	@Column(name="ATTRIBUTE6")
	private Date attribute6;
	
	@Column(name="ATTRIBUTE7")
	private Date attribute7;
	
	@Column(name="IP_ADDRESS")
	private String IpAddress;

	public MasterEntry() {
		super();
		
	}

	
	public MasterEntry(long id, String lookupCode, String lookupType, String value, String description, String createdBy,
			Date createdOn, String modifiedBy, String attribute1, String attribute2, String attribute3,
			Integer attribute4, Integer attribute5, Date attribute6, Date attribute7, String ipAddress) {
		super();
		this.id = id;
		this.lookupCode = lookupCode;
		this.lookupType = lookupType;
		this.value = value;
		this.description = description;
		this.createdBy = createdBy;
		this.createdOn = createdOn;
		this.modifiedBy = modifiedBy;
		this.attribute1 = attribute1;
		this.attribute2 = attribute2;
		this.attribute3 = attribute3;
		this.attribute4 = attribute4;
		this.attribute5 = attribute5;
		this.attribute6 = attribute6;
		this.attribute7 = attribute7;
		IpAddress = ipAddress;
	}






	public String getIpAddress() {
		return IpAddress;
	}



	public void setIpAddress(String ipAddress) {
		IpAddress = ipAddress;
	}



	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getLookupCode() {
		return lookupCode;
	}

	public void setLookupCode(String lookupCode) {
		this.lookupCode = lookupCode;
	}

	public String getLookupType() {
		return lookupType;
	}

	public void setLookupType(String lookupType) {
		this.lookupType = lookupType;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public String getAttribute1() {
		return attribute1;
	}

	public void setAttribute1(String attribute1) {
		this.attribute1 = attribute1;
	}

	public String getAttribute2() {
		return attribute2;
	}

	public void setAttribute2(String attribute2) {
		this.attribute2 = attribute2;
	}

	public String getAttribute3() {
		return attribute3;
	}

	public void setAttribute3(String attribute3) {
		this.attribute3 = attribute3;
	}

	public Integer getAttribute4() {
		return attribute4;
	}

	public void setAttribute4(Integer attribute4) {
		this.attribute4 = attribute4;
	}

	public Integer getAttribute5() {
		return attribute5;
	}

	public void setAttribute5(Integer attribute5) {
		this.attribute5 = attribute5;
	}

	public Date getAttribute6() {
		return attribute6;
	}

	public void setAttribute6(Date attribute6) {
		this.attribute6 = attribute6;
	}

	public Date getAttribute7() {
		return attribute7;
	}

	public void setAttribute7(Date attribute7) {
		this.attribute7 = attribute7;
	}


	@Override
	public String toString() {
		return "MasterEntry [id=" + id + ", lookupCode=" + lookupCode + ", lookupType=" + lookupType + ", value="
				+ value + ", description=" + description + ", createdBy=" + createdBy + ", createdOn=" + createdOn
				+ ", modifiedBy=" + modifiedBy + ", attribute1=" + attribute1 + ", attribute2=" + attribute2
				+ ", attribute3=" + attribute3 + ", attribute4=" + attribute4 + ", attribute5=" + attribute5
				+ ", attribute6=" + attribute6 + ", attribute7=" + attribute7 + ", IpAddress=" + IpAddress + "]";
	}

	
	
	

}
