package com.lg.csnet.exception;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExcepNew {
	
	@ExceptionHandler(value = Exception.class)
	public String globalExcepHandler(Model model) {
		
		System.out.println("which type exception occured--" +Exception.class.getSimpleName());
		model.addAttribute("message",Exception.class.getSimpleName());
		return "null_page1";
		
	}

}
