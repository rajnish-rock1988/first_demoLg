package com.lg.csnet.exception;

public class ForgetPasswordException {

}
