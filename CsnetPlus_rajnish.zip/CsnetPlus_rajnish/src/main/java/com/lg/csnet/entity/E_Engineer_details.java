	package com.lg.csnet.entity;

	
	import java.util.Date;
	import javax.persistence.Column;
	import javax.persistence.Entity;
	import javax.persistence.Id;
	import javax.persistence.Table;
	
@Entity
@Table(name="DNET_ENGINEER_MST_NEW")
public class E_Engineer_details {
	
	    @Id
	    //@GeneratedValue( strategy = GenerationType.IDENTITY)
	    @Column(name="EMPLOYEE_ID")
	    private String employeeId;
	    
	    @Column(name="BRANCH")
	    private String branch;
	    
	    @Column(name="ASC_VALUE")
	    private String asc;
	    
	    @Column(name="ASC_TYPE")
	    private String ascType;
	    
	    @Column(name="COMPANY_ID")
	    private String companyId;
	    
	    @Column(name="SHIFT_TO_CODE")
	    private String shiftToCode;
	    
	    @Column(name="FIRST_NAME")
	    private String firstName;
	    
	    @Column(name="MIDDLE_NAME")
	    private String middleName;
	    
	    @Column(name="LAST_NAME")
	    private String lastName;
	    
	    @Column(name="DESIGNATION")
	    private String designation;
	    
	    @Column(name="CURRENT_ADDRESS")
	    private String currentAddress;
	    
	    @Column(name="PERMANAT_ADDRESS")
	    private String permanatAddress;
	    
	    @Column(name="DATE_OF_BIRTH")
	    private Date dateOfBirth;
	    
	    @Column(name="MOBILE_NUMBER")
	    private String mobileNumber;
	    
	    @Column(name="TELEPHONE_NUMBER")
	    private String telephoneNumber;
	    
	    @Column(name="STATE")
	    private String state;
	    
	    @Column(name="AADHAR_NO")
	    private String aadharNo;
	    
	    @Column(name="CITY")
	    private String city;
	    
	    @Column(name="GENDER")
	    private String gender;
	    
	    @Column(name="EMAIL_ID")
	    private String emailId;
	    
	    @Column(name="LG_JOIN_DATE")
	    private Date lgJoinDate;
	    
	    @Column(name="EXP1_TYPE")
	    private String exp1Type;
	    
	    @Column(name="EXP1_NAME_OF_COMPANY")
	    private String exp1NameOfCompany;
	    
	    @Column(name="EXP1_FIRM_NAME_AND_CITY")
	    private String exp1FirmNameAndCity;
	    
	    @Column(name="EXP1_FROM_DATE")
	    private Date exp1FromDate;
	    
	    @Column(name="EXP1_TO_DATE")
	    private Date exp1ToDate;
	    
	    @Column(name="EXP2_TYPE")
	    private String exp2Type;
	    
	    @Column(name="EXP2_NAME_OF_COMPANY")
	    private String exp2NameOfCompany;
	    
	    @Column(name="EXP2_FIRM_NAME_AND_CITY")
	    private String exp2FirmNameAndCity;
	    
	    @Column(name="EXP2_FROM_DATE")
	    private Date exp2FromDate;
	    
	    @Column(name="EXP2_TO_DATE")
	    private Date exp2ToDate;
	    
	    @Column(name="EXP3_TYPE")
	    private String exp3Type;
	    
	    @Column(name="EXP3_NAME_OF_COMPANY")
	    private String exp3NameOfCompany;
	    
	    @Column(name="EXP3_FIRM_NAME_AND_CITY")
	    private String exp3FirmNameAndCity;
	    
	    @Column(name="EXP3_FROM_DATE")
	    private Date exp3FromDate;
	    
	    @Column(name="EXP3_TO_DATE")
	    private Date exp3ToDate;
	    
	    @Column(name="BASIC_QUALIFICATION")
	    private String basicQualification;
	    
	    @Column(name="OTHER_QUALIFICATION")
	    private String otherQualification;
	    
	    @Column(name="NOMINEE_NAME")
	    private String nomineeName;

	    @Column(name="RELATION_WITH_EMPLOYEE")
	    private String relationWtihEmployee;
	    
	    @Column(name="SALARY_IN_HAND")
	    private double salaryInHand;
	    
	    @Column(name="INCENTIVE")
	    private double incentive;
	    
	    @Column(name="CONVEYANCE_TYPE")
	    private String conveyanceType;
	    
	    @Column(name="CONVEYANCE_RATE")
	    private double conveyanceRate;
	    
	    @Column(name="ESPY")
	    private String espy;
	    
	    @Column(name="MOBILE_CHARGES")
	    private String mobileCharges;
	    
	    @Column(name="LAST_INCENTIVE")
	    private Date lastIncentive;
	    
	    @Column(name="LAST_SALARY_PAID_BY_ASC")
	    private String lastSalaryPaidByAsc; 
	    
	    @Column(name="RMODE")
	    private String rMode;
	    
	    @Column(name="CREATION_DATE")
	    private Date creationDate;
	    
	    @Column(name="CREATED_BY")
	    private String createdBy;
	    
	    @Column(name="LAST_UPDATE_DATE")
	    private Date lastUpdatedDate;
	    
	    @Column(name="LAST_UPDATED_BY")
	    private String lastUpdatedBy;
	    
	    @Column(name="ENG_STATUS")
	    private String engStatus;
	    
	    @Column(name="ENG_RESUME_FNAME")
	    private String engResumeFName;
	    
	    @Column(name="ENG_PHOTO_FNAME")
	    private String engPhotoFName;
	    
	    @Column(name="ENG_FNAME_QUALIFICATION")
	    private String engFNameQuali;
	    
	    @Column(name="ENG_ADHAR_FNAME")
	    private String engAdharFname;
	    
		public String getEmployeeId() {
			return employeeId;
		}

		public void setEmployeeId(String employeeId) {
			this.employeeId = employeeId;
		}

		public String getBranch() {
			return branch;
		}

		public void setBranch(String branch) {
			this.branch = branch;
		}

		public String getCompanyId() {
			return companyId;
		}

		public void setCompanyId(String companyId) {
			this.companyId = companyId;
		}

		public String getShiftToCode() {
			return shiftToCode;
		}

		public void setShiftToCode(String shiftToCode) {
			this.shiftToCode = shiftToCode;
		}

		public String getFirstName() {
			return firstName;
		}

		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}

		public String getMiddleName() {
			return middleName;
		}

		public void setMiddleName(String middleName) {
			this.middleName = middleName;
		}

		public String getLastName() {
			return lastName;
		}

		public void setLastName(String lastName) {
			this.lastName = lastName;
		}

		public String getDesignation() {
			return designation;
		}

		public void setDesignation(String designation) {
			this.designation = designation;
		}

		public String getCurrentAddress() {
			return currentAddress;
		}

		public void setCurrentAddress(String currentAddress) {
			this.currentAddress = currentAddress;
		}

		public String getPermanatAddress() {
			return permanatAddress;
		}

		public void setPermanatAddress(String permanatAddress) {
			this.permanatAddress = permanatAddress;
		}

		public Date getDateOfBirth() {
			return dateOfBirth;
		}

		public void setDateOfBirth(Date dateOfBirth) {
			this.dateOfBirth = dateOfBirth;
		}

		public String getMobileNumber() {
			return mobileNumber;
		}

		public void setMobileNumber(String mobileNumber) {
			this.mobileNumber = mobileNumber;
		}

		public String getTelephoneNumber() {
			return telephoneNumber;
		}

		public void setTelephoneNumber(String telephoneNumber) {
			this.telephoneNumber = telephoneNumber;
		}

		public String getState() {
			return state;
		}

		public void setState(String state) {
			this.state = state;
		}

		public String getAadharNo() {
			return aadharNo;
		}

		public void setAadharNo(String aadharNo) {
			this.aadharNo = aadharNo;
		}

		public String getCity() {
			return city;
		}

		public void setCity(String city) {
			this.city = city;
		}

		public String getGender() {
			return gender;
		}

		public void setGender(String gender) {
			this.gender = gender;
		}

		public String getEmailId() {
			return emailId;
		}

		public void setEmailId(String emailId) {
			this.emailId = emailId;
		}

		public Date getLgJoinDate() {
			return lgJoinDate;
		}

		public void setLgJoinDate(Date lgJoinDate) {
			this.lgJoinDate = lgJoinDate;
		}

		public String getExp1Type() {
			return exp1Type;
		}

		public void setExp1Type(String exp1Type) {
			this.exp1Type = exp1Type;
		}

		public String getExp1NameOfCompany() {
			return exp1NameOfCompany;
		}

		public void setExp1NameOfCompany(String exp1NameOfCompany) {
			this.exp1NameOfCompany = exp1NameOfCompany;
		}

		public String getExp1FirmNameAndCity() {
			return exp1FirmNameAndCity;
		}

		public void setExp1FirmNameAndCity(String exp1FirmNameAndCity) {
			this.exp1FirmNameAndCity = exp1FirmNameAndCity;
		}

		public Date getExp1FromDate() {
			return exp1FromDate;
		}

		public void setExp1FromDate(Date exp1FromDate) {
			this.exp1FromDate = exp1FromDate;
		}

		public Date getExp1ToDate() {
			return exp1ToDate;
		}

		public void setExp1ToDate(Date exp1ToDate) {
			this.exp1ToDate = exp1ToDate;
		}

		public String getExp2Type() {
			return exp2Type;
		}

		public void setExp2Type(String exp2Type) {
			this.exp2Type = exp2Type;
		}

		public String getExp2NameOfCompany() {
			return exp2NameOfCompany;
		}

		public void setExp2NameOfCompany(String exp2NameOfCompany) {
			this.exp2NameOfCompany = exp2NameOfCompany;
		}

		public String getExp2FirmNameAndCity() {
			return exp2FirmNameAndCity;
		}

		public void setExp2FirmNameAndCity(String exp2FirmNameAndCity) {
			this.exp2FirmNameAndCity = exp2FirmNameAndCity;
		}

		public Date getExp2FromDate() {
			return exp2FromDate;
		}

		public void setExp2FromDate(Date exp2FromDate) {
			this.exp2FromDate = exp2FromDate;
		}

		public Date getExp2ToDate() {
			return exp2ToDate;
		}

		public void setExp2ToDate(Date exp2ToDate) {
			this.exp2ToDate = exp2ToDate;
		}

		public String getExp3Type() {
			return exp3Type;
		}

		public void setExp3Type(String exp3Type) {
			this.exp3Type = exp3Type;
		}

		public String getExp3NameOfCompany() {
			return exp3NameOfCompany;
		}

		public void setExp3NameOfCompany(String exp3NameOfCompany) {
			this.exp3NameOfCompany = exp3NameOfCompany;
		}

		public String getExp3FirmNameAndCity() {
			return exp3FirmNameAndCity;
		}

		public void setExp3FirmNameAndCity(String exp3FirmNameAndCity) {
			this.exp3FirmNameAndCity = exp3FirmNameAndCity;
		}

		public Date getExp3FromDate() {
			return exp3FromDate;
		}

		public void setExp3FromDate(Date exp3FromDate) {
			this.exp3FromDate = exp3FromDate;
		}

		public Date getExp3ToDate() {
			return exp3ToDate;
		}

		public void setExp3ToDate(Date exp3ToDate) {
			this.exp3ToDate = exp3ToDate;
		}

		public String getBasicQualification() {
			return basicQualification;
		}

		public void setBasicQualification(String basicQualification) {
			this.basicQualification = basicQualification;
		}

		public String getOtherQualification() {
			return otherQualification;
		}

		public void setOtherQualification(String otherQualification) {
			this.otherQualification = otherQualification;
		}

		public String getNomineeName() {
			return nomineeName;
		}

		public void setNomineeName(String nomineeName) {
			this.nomineeName = nomineeName;
		}

		public String getRelationWtihEmployee() {
			return relationWtihEmployee;
		}

		public void setRelationWtihEmployee(String relationWtihEmployee) {
			this.relationWtihEmployee = relationWtihEmployee;
		}

		public double getSalaryInHand() {
			return salaryInHand;
		}

		public void setSalaryInHand(double salaryInHand) {
			this.salaryInHand = salaryInHand;
		}

		public double getIncentive() {
			return incentive;
		}

		public void setIncentive(double incentive) {
			this.incentive = incentive;
		}

		public String getConveyanceType() {
			return conveyanceType;
		}

		public void setConveyanceType(String conveyanceType) {
			this.conveyanceType = conveyanceType;
		}

		public double getConveyanceRate() {
			return conveyanceRate;
		}

		public void setConveyanceRate(double conveyanceRate) {
			this.conveyanceRate = conveyanceRate;
		}

		public String getEspy() {
			return espy;
		}

		public void setEspy(String espy) {
			this.espy = espy;
		}

		public String getMobileCharges() {
			return mobileCharges;
		}

		public void setMobileCharges(String mobileCharges) {
			this.mobileCharges = mobileCharges;
		}

		public Date getLastIncentive() {
			return lastIncentive;
		}

		public void setLastIncentive(Date lastIncentive) {
			this.lastIncentive = lastIncentive;
		}

		public String getLastSalaryPaidByAsc() {
			return lastSalaryPaidByAsc;
		}

		public void setLastSalaryPaidByAsc(String lastSalaryPaidByAsc) {
			this.lastSalaryPaidByAsc = lastSalaryPaidByAsc;
		}

		public String getrMode() {
			return rMode;
		}

		public void setrMode(String rMode) {
			this.rMode = rMode;
		}

		public Date getCreationDate() {
			return creationDate;
		}

		public void setCreationDate(Date creationDate) {
			this.creationDate = creationDate;
		}

		public String getCreatedBy() {
			return createdBy;
		}

		public void setCreatedBy(String createdBy) {
			this.createdBy = createdBy;
		}

		public Date getLastUpdatedDate() {
			return lastUpdatedDate;
		}

		public void setLastUpdatedDate(Date lastUpdatedDate) {
			this.lastUpdatedDate = lastUpdatedDate;
		}

		public String getLastUpdatedBy() {
			return lastUpdatedBy;
		}

		public void setLastUpdatedBy(String lastUpdatedBy) {
			this.lastUpdatedBy = lastUpdatedBy;
		}

		public String getEngStatus() {
			return engStatus;
		}

		public void setEngStatus(String engStatus) {
			this.engStatus = engStatus;
		}

		public String getEngResumeFName() {
			return engResumeFName;
		}

		public void setEngResumeFName(String engResumeFName) {
			this.engResumeFName = engResumeFName;
		}

		public String getEngPhotoFName() {
			return engPhotoFName;
		}

		public void setEngPhotoFName(String engPhotoFName) {
			this.engPhotoFName = engPhotoFName;
		}

		public String getEngFNameQuali() {
			return engFNameQuali;
		}

		public void setEngFNameQuali(String engFNameQuali) {
			this.engFNameQuali = engFNameQuali;
		}

		public String getAsc() {
			return asc;
		}

		public void setAsc(String asc) {
			this.asc = asc;
		}

		public String getAscType() {
			return ascType;
		}

		public void setAscType(String ascType) {
			this.ascType = ascType;
		}

		public String getEngAdharFname() {
			return engAdharFname;
		}

		public void setEngAdharFname(String engAdharFname) {
			this.engAdharFname = engAdharFname;
		}

		@Override
		public String toString() {
			return "E_Engineer_details [employeeId=" + employeeId + ", branch=" + branch + ", asc=" + asc + ", ascType="
					+ ascType + ", companyId=" + companyId + ", shiftToCode=" + shiftToCode + ", firstName=" + firstName
					+ ", middleName=" + middleName + ", lastName=" + lastName + ", designation=" + designation
					+ ", currentAddress=" + currentAddress + ", permanatAddress=" + permanatAddress + ", dateOfBirth="
					+ dateOfBirth + ", mobileNumber=" + mobileNumber + ", telephoneNumber=" + telephoneNumber
					+ ", state=" + state + ", aadharNo=" + aadharNo + ", city=" + city + ", gender=" + gender
					+ ", emailId=" + emailId + ", lgJoinDate=" + lgJoinDate + ", exp1Type=" + exp1Type
					+ ", exp1NameOfCompany=" + exp1NameOfCompany + ", exp1FirmNameAndCity=" + exp1FirmNameAndCity
					+ ", exp1FromDate=" + exp1FromDate + ", exp1ToDate=" + exp1ToDate + ", exp2Type=" + exp2Type
					+ ", exp2NameOfCompany=" + exp2NameOfCompany + ", exp2FirmNameAndCity=" + exp2FirmNameAndCity
					+ ", exp2FromDate=" + exp2FromDate + ", exp2ToDate=" + exp2ToDate + ", exp3Type=" + exp3Type
					+ ", exp3NameOfCompany=" + exp3NameOfCompany + ", exp3FirmNameAndCity=" + exp3FirmNameAndCity
					+ ", exp3FromDate=" + exp3FromDate + ", exp3ToDate=" + exp3ToDate + ", basicQualification="
					+ basicQualification + ", otherQualification=" + otherQualification + ", nomineeName=" + nomineeName
					+ ", relationWtihEmployee=" + relationWtihEmployee + ", salaryInHand=" + salaryInHand
					+ ", incentive=" + incentive + ", conveyanceType=" + conveyanceType + ", conveyanceRate="
					+ conveyanceRate + ", espy=" + espy + ", mobileCharges=" + mobileCharges + ", lastIncentive="
					+ lastIncentive + ", lastSalaryPaidByAsc=" + lastSalaryPaidByAsc + ", rMode=" + rMode
					+ ", creationDate=" + creationDate + ", createdBy=" + createdBy + ", lastUpdatedDate="
					+ lastUpdatedDate + ", lastUpdatedBy=" + lastUpdatedBy + ", engStatus=" + engStatus
					+ ", engResumeFName=" + engResumeFName + ", engPhotoFName=" + engPhotoFName + ", engFNameQuali="
					+ engFNameQuali + ", engAdharFname=" + engAdharFname + ", getEmployeeId()=" + getEmployeeId()
					+ ", getBranch()=" + getBranch() + ", getCompanyId()=" + getCompanyId() + ", getShiftToCode()="
					+ getShiftToCode() + ", getFirstName()=" + getFirstName() + ", getMiddleName()=" + getMiddleName()
					+ ", getLastName()=" + getLastName() + ", getDesignation()=" + getDesignation()
					+ ", getCurrentAddress()=" + getCurrentAddress() + ", getPermanatAddress()=" + getPermanatAddress()
					+ ", getDateOfBirth()=" + getDateOfBirth() + ", getMobileNumber()=" + getMobileNumber()
					+ ", getTelephoneNumber()=" + getTelephoneNumber() + ", getState()=" + getState()
					+ ", getAadharNo()=" + getAadharNo() + ", getCity()=" + getCity() + ", getGender()=" + getGender()
					+ ", getEmailId()=" + getEmailId() + ", getLgJoinDate()=" + getLgJoinDate() + ", getExp1Type()="
					+ getExp1Type() + ", getExp1NameOfCompany()=" + getExp1NameOfCompany()
					+ ", getExp1FirmNameAndCity()=" + getExp1FirmNameAndCity() + ", getExp1FromDate()="
					+ getExp1FromDate() + ", getExp1ToDate()=" + getExp1ToDate() + ", getExp2Type()=" + getExp2Type()
					+ ", getExp2NameOfCompany()=" + getExp2NameOfCompany() + ", getExp2FirmNameAndCity()="
					+ getExp2FirmNameAndCity() + ", getExp2FromDate()=" + getExp2FromDate() + ", getExp2ToDate()="
					+ getExp2ToDate() + ", getExp3Type()=" + getExp3Type() + ", getExp3NameOfCompany()="
					+ getExp3NameOfCompany() + ", getExp3FirmNameAndCity()=" + getExp3FirmNameAndCity()
					+ ", getExp3FromDate()=" + getExp3FromDate() + ", getExp3ToDate()=" + getExp3ToDate()
					+ ", getBasicQualification()=" + getBasicQualification() + ", getOtherQualification()="
					+ getOtherQualification() + ", getNomineeName()=" + getNomineeName()
					+ ", getRelationWtihEmployee()=" + getRelationWtihEmployee() + ", getSalaryInHand()="
					+ getSalaryInHand() + ", getIncentive()=" + getIncentive() + ", getConveyanceType()="
					+ getConveyanceType() + ", getConveyanceRate()=" + getConveyanceRate() + ", getEspy()=" + getEspy()
					+ ", getMobileCharges()=" + getMobileCharges() + ", getLastIncentive()=" + getLastIncentive()
					+ ", getLastSalaryPaidByAsc()=" + getLastSalaryPaidByAsc() + ", getrMode()=" + getrMode()
					+ ", getCreationDate()=" + getCreationDate() + ", getCreatedBy()=" + getCreatedBy()
					+ ", getLastUpdatedDate()=" + getLastUpdatedDate() + ", getLastUpdatedBy()=" + getLastUpdatedBy()
					+ ", getEngStatus()=" + getEngStatus() + ", getEngResumeFName()=" + getEngResumeFName()
					+ ", getEngPhotoFName()=" + getEngPhotoFName() + ", getEngFNameQuali()=" + getEngFNameQuali()
					+ ", getAsc()=" + getAsc() + ", getAscType()=" + getAscType() + ", getEngAdharFname()="
					+ getEngAdharFname() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()="
					+ super.toString() + "]";
		}
	    
		
	    
		
		
	   
}