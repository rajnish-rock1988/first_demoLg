package com.lg.csnet.exception;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

@ControllerAdvice
public class GlobalException {
	
	
	@Value("${Exceptionmessage.globalMessage}")
	String globalMessage;

	@ResponseStatus(value = HttpStatus.NOT_FOUND)
	@ExceptionHandler(value = InternalError.class)
	public String exceptionHandler404(Model model) {
		System.out.println("page not founf 404");
		model.addAttribute("message", globalMessage);
		return "null_page1";
	}
	
	
	@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
	@ExceptionHandler(value = NullPointerException.class)
	public String exceptionHandlerNull(Model model) {
		model.addAttribute("message", "NullPointer Exception has occured ");
		//model.addAttribute("message", globalMessage);
		return "null_page1";
	}

	
	
	@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
	@ExceptionHandler(value = NumberFormatException.class)
	public String exceptionHandlerNumberFormat(Model model) {
	model.addAttribute("message", "Numberformat Exception has occured ");
	return "null_page1";

	}
	
//	@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
/*	@ExceptionHandler(value = Exception.class)
	public String exceptionHandlerGeneric(Model model) {
	model.addAttribute("message", globalMessage);
	return "null_page1";

	}*/

}
