package com.lg.csnet.service;

import java.util.List;

import com.lg.csnet.entity.MasterEntry;
import com.lg.csnet.entity.UserLg;
import com.lg.csnet.repository.MainMasterRepository;

public interface MainMasterService  {
	
	
	

	
	 public void saveMaster(MasterEntry masterEntry);
	 
	 
		/*
		 * public static Object getAllMasterSearch() {
		 * 
		 * return (List<MasterEntry>) mainMasterRepository.findAll(); }
		 */
	 
		/*
		 * public static List<MasterEntry> findById(long id) { return
		 * mainMasterRepository.findById(id); }
		 */

}
