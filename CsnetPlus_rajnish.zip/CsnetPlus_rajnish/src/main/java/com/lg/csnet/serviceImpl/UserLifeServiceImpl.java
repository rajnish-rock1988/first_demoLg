 /**
 * 
 */
package com.lg.csnet.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lg.csnet.entity.UserLg;
import com.lg.csnet.repository.UserLifeRepository;
import com.lg.csnet.service.UserLifeService;

/**
 * @author LIVE
 *
 */

@Service
public class UserLifeServiceImpl implements UserLifeService {
	
	@Autowired
	private UserLifeRepository userLifeRepository;

	@Override
	public void saveUser(UserLg Userlg) {
		
		 UserLg save = userLifeRepository.save(Userlg);
		 System.out.println("save data is-->"+save);
		
	}

	@Override
	public String updateUser(UserLg userlg) {
		
		return null;
	}
	

}
