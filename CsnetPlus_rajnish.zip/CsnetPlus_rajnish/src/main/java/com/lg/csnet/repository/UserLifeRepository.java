package com.lg.csnet.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.lg.csnet.entity.UserLg;

public interface UserLifeRepository extends  JpaRepository<UserLg, Long> {
   
	
	@Transactional
	@Modifying
	@Query(value = "UPDATE lg_user SET ip_address =:ipAdd  WHERE login_id=:loginId", nativeQuery = true)//AND created_date=:date
	 void addIpaddForUserCreation(String loginId,String ipAdd);

	
	@Query( value = "SELECT * FROM lg_user WHERE login_id=:loginId", nativeQuery = true) // search userLg
	List<UserLg> findById(String loginId);
	
	@Query( value = "SELECT login_Id  FROM lg_user WHERE login_Id=:loginId", nativeQuery = true) // search userLg
	List<String> findByDupLoginId(String loginId);


	
	
	
}
