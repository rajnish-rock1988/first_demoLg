package com.lg.csnet.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.lg.csnet.entity.MasterEntry;
import com.lg.csnet.entity.UserLg;
import com.lg.csnet.repository.MainMasterRepository;

@Controller
public class SearchMasterController {
	
	@Autowired
	private MainMasterRepository mainMasterRepository;
	
	@GetMapping("/searchMaster")
	public String searchMasterEntry(Model model,HttpServletRequest request) {
		
		System.out.println("Searching MasterEntry");
		return "searchMaster";
		
	}
	
	@PostMapping("/searchMasterId")
	public String searchMaster(HttpServletRequest request,ModelMap model) {
		
		String value= request.getParameter("value");
		String lookupCode= request.getParameter("lookupCode");
		String lookupType=request.getParameter("lookupType");
		System.out.println("value in String===="+value);
		System.out.println("longlookupCode in String===="+lookupType);
		System.out.println("lookupType is" + lookupType);
		
		model.addAttribute("value", value);
		model.addAttribute("lookupCode", lookupCode);
		model.addAttribute("lookupType", lookupType);
		
		long longId;
		
		List<MasterEntry> masterEntries;
		
		if(value!=null || lookupCode!=null || lookupType!=null) {
		
		 masterEntries = mainMasterRepository.searchData(lookupCode,lookupType,value);
		System.out.println("searchMaster using lookCode and lookType" + masterEntries);
		
		model.addAttribute("searchMasterResult", masterEntries);
		return "searchMaster";		
		}else {
			model.addAttribute("error", "Data Not Found!");
			return "searchMaster";
			
		}
		
		//List<MasterEntry> masterEntries = mainMasterRepository.searchData(l,lookupType);
		
		/*
		 * masterEntries.forEach(e-> { System.out.println(e); });
		 */
		/*
		 * List<MasterEntry> findByLookupCodeResult =
		 * mainMasterRepository.findByLookUpCode(lookupCode);
		 * System.out.println("searchMaster using lookCode " + findByLookupCodeResult);
		 * 
		 * List<MasterEntry> findByLookupTypeResult =
		 * mainMasterRepository.findByLookUpType(lookupType);
		 * System.out.println("searchMaster using lookType " + findByLookupTypeResult);
		 */
		
		 
		//  model.addAttribute( "searchMasterResult " ,findByLookCodeAndLookType);
		  
		 
		
	/*	if(id!=null || id.isEmpty() ) {
			longId=Long.parseLong(id);
		List<MasterEntry> findByIdResult = mainMasterRepository.findById(longId);
		System.out.println("get details using searchMaster----" + findByIdResult.size());
		if (id != null) {

			model.addAttribute("searchMasterResult", findByIdResult);
			return "searchMaster";

		} else {

		}
		}*/
		
		//return "searchMaster";
		
	}

}
