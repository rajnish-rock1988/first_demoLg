package com.lg.csnet.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lg.csnet.entity.MasterEntry;
import com.lg.csnet.entity.UserLg;
import com.lg.csnet.repository.MainMasterRepository;
import com.lg.csnet.service.MainMasterService;


@Service
public class MainMasterServiceImpl implements MainMasterService {
	
	
	@Autowired
	private MainMasterRepository mainMasterRepository;

	
	  @Override
	  public void saveMaster(MasterEntry masterEntry) {
	  
	  System.out.println("Mastersave data before save-->" + masterEntry );
	  
	  
	  MasterEntry save = mainMasterRepository.save(masterEntry);
	  System.out.println("Mastersave data is-->" + save);
	  
	  
	  }
	 

}
