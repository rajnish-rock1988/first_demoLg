package com.lg.csnet.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="DNET_USER_MST_NEW_HIST")
public class LgUserHistory {
	
	@Column(name="AFFILIATE_CODE")
	private String affiliateCode;
	
	@Id
	@Column(name="ID")
	private long id;
	
	@Column(name="LOGIN_ID")
	private String loginId;
	
	@Column(name="USER_REF_ID")
	private String userRefId;
	
	@Column(name="PASSWORD")
	private String password;
	
	@Column(name="LOGIN_NAME")
	private String loginName;
	
	@Column(name="LOGIN_EMAIL_ID")
	private String email;
	
	@Column(name="ACTIVE_STATUS")
	private String activeStatus;
	
	@Column(name="ADMIN_USER")
	private String adminUser;
	
	@Column(name="USER_TYPE")
	private String userType;
	
	@Column(name="USER_SUB_TYPE")
	private String userSubType;
	
	@Column(name="LOGIN_TYPE")
	private String loginType;
	
	@Column(name="CREATION_DATE")
	private Date creationDate=new Date(System.currentTimeMillis());
	
	@Column(name="CREATED_BY")
	private String createdBy;
	
	@Column(name="LAST_UPDATE_DATE")
	private Date lastUpdatedDate=new Date(System.currentTimeMillis());
	
	@Column(name="LAST_UPDATED_BY")
	private String lastUpdatedBy;

	public LgUserHistory() {
		super();
		
	}

	public LgUserHistory(String affiliateCode, long id, String loginId, String userRefId, String password,
			String loginName, String email, String activeStatus, String adminUser, String userType, String userSubType,
			String loginType, Date creationDate, String createdBy, Date lastUpdatedDate, String lastUpdatedBy) {
		super();
		this.affiliateCode = affiliateCode;
		this.id = id;
		this.loginId = loginId;
		this.userRefId = userRefId;
		this.password = password;
		this.loginName = loginName;
		this.email = email;
		this.activeStatus = activeStatus;
		this.adminUser = adminUser;
		this.userType = userType;
		this.userSubType = userSubType;
		this.loginType = loginType;
		this.creationDate = creationDate;
		this.createdBy = createdBy;
		this.lastUpdatedDate = lastUpdatedDate;
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public String getAffiliateCode() {
		return affiliateCode;
	}

	public void setAffiliateCode(String affiliateCode) {
		this.affiliateCode = affiliateCode;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getLoginId() {
		return loginId;
	}

	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	public String getUserRefId() {
		return userRefId;
	}

	public void setUserRefId(String userRefId) {
		this.userRefId = userRefId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getLoginName() {
		return loginName;
	}

	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getActiveStatus() {
		return activeStatus;
	}

	public void setActiveStatus(String activeStatus) {
		this.activeStatus = activeStatus;
	}

	public String getAdminUser() {
		return adminUser;
	}

	public void setAdminUser(String adminUser) {
		this.adminUser = adminUser;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getUserSubType() {
		return userSubType;
	}

	public void setUserSubType(String userSubType) {
		this.userSubType = userSubType;
	}

	public String getLoginType() {
		return loginType;
	}

	public void setLoginType(String loginType) {
		this.loginType = loginType;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}
	
	

}
