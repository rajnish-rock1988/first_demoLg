package com.lg.csnet.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.lg.csnet.entity.UserLg;
import com.lg.csnet.service.UserLifeService;

@Controller
public class UpdateUserLgController {
	
	@Autowired
	private UserLifeService userLifeService;
	
	
	@GetMapping("/updateUser")
	public String updateUserLg(@ModelAttribute UserLg userLg, Model model, HttpServletRequest request) {
		
		System.out.println("Update paging ");
		String loginId = request.getParameter("loginId");
	    System.out.println("loginid is--->" + loginId);
	    
	    if(loginId != null) {
	    	
	    	userLifeService.updateUser(userLg);
	    	
	    }
	    
	    model.addAttribute("SUCCESS", "Updated Successfully");
	    
	    model.addAttribute("Error", "Updated not successfully");
	    
		return "updateUser";
		
	}

}
