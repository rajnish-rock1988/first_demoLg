package com.lg.csnet.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ZIP_CODE_MASTER")
public class StateCityDropDown {
	@Id
	@Column(name="ZIP_CODE_ID")
	private long zipCodeId;
	
	@Column(name="ZIP_CODE")
    private int zipCode;
	
	@Column(name="STATE_ID")
    private int stateId;
    
	@Column(name="STATE_NAME")
    private String stateName;
    
	@Column(name="CITY_ID")
    private int cityId;
    
	@Column(name="CITY_NAME")
    private String cityName;
    
	@Column(name="DELETE_FLAG")
    private String deleteFlag;
    
	@Column(name="CREATED_BY")
    private String createdBy;
    
	@Column(name="CREATED_DATE")
    private Date createdDate;

	@Column(name="LAST_MODIFIED_BY")    
    private String lastModifiedBy;
    
	@Column(name="LAST_MODIFY_DATE")    
    private Date lastModifiedDate;
	
	

	public StateCityDropDown() {
		super();
		// TODO Auto-generated constructor stub
	}

	public StateCityDropDown(long zipCodeId, int zipCode, int stateId, String stateName, int cityId, String cityName,
			String deleteFlag, String createdBy, Date createdDate, String lastModifiedBy, Date lastModifiedDate) {
		super();
		this.zipCodeId = zipCodeId;
		this.zipCode = zipCode;
		this.stateId = stateId;
		this.stateName = stateName;
		this.cityId = cityId;
		this.cityName = cityName;
		this.deleteFlag = deleteFlag;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
		this.lastModifiedBy = lastModifiedBy;
		this.lastModifiedDate = lastModifiedDate;
	}

	public long getZipCodeId() {
		return zipCodeId;
	}

	public void setZipCodeId(long zipCodeId) {
		this.zipCodeId = zipCodeId;
	}

	public int getZipCode() {
		return zipCode;
	}

	public void setZipCode(int zipCode) {
		this.zipCode = zipCode;
	}

	public int getStateId() {
		return stateId;
	}

	public void setStateId(int stateId) {
		this.stateId = stateId;
	}

	public String getStateName() {
		return stateName;
	}

	public void setStateName(String stateName) {
		this.stateName = stateName;
	}

	public int getCityId() {
		return cityId;
	}

	public void setCityId(int cityId) {
		this.cityId = cityId;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public String getDeleteFlag() {
		return deleteFlag;
	}

	public void setDeleteFlag(String deleteFlag) {
		this.deleteFlag = deleteFlag;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	@Override
	public String toString() {
		return "StateCityDropDown [zipCodeId=" + zipCodeId + ", zipCode=" + zipCode + ", stateId=" + stateId
				+ ", stateName=" + stateName + ", cityId=" + cityId + ", cityName=" + cityName + ", deleteFlag="
				+ deleteFlag + ", createdBy=" + createdBy + ", createdDate=" + createdDate + ", lastModifiedBy="
				+ lastModifiedBy + ", lastModifiedDate=" + lastModifiedDate + "]";
	}
	
	

}
