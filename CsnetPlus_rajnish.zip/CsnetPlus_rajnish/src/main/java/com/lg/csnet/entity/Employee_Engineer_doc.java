package com.lg.csnet.entity;


import java.util.Arrays;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
//import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;


@Entity
@Table(name="DNET_ENGINEER_MST_DOCUMENT")
public class Employee_Engineer_doc {
	@Id
	//@GeneratedValue( strategy = GenerationType.AUTO)
	@GeneratedValue(generator="system-uuid")
	@GenericGenerator(name="system-uuid", strategy = "uuid")
	@Column(name="ID")
	private String id;
	
	
	@Column(name="EMPLOYEE_ID")
	private String employee_id;
	
	@Lob	
	@Column(name="ENG_RESUME")
	private byte[] eng_resume;
	
	@Column(name="ENG_RESUME_NAME")
	private String engResumeName;
	
	@Lob
	@Column(name="ENG_PHOTO")
	private byte[] eng_photo;
	
	@Column(name="ENG_PHOTO_NAME")
	private String engPhotoName;
	
	@Lob
	@Column(name="ENG_QUALIFICATION")
	private byte[] eng_qualification;
	
	@Column(name="ENG_NAME_QUALIFICATION")
	private String engNameQualifi;
	
	@Lob
	@Column(name="ENG_ADHAR")
	private byte[] eng_adhar;
	
	@Column(name="ENG_ADHAR_NAME")
	private String engAdharName;
		
	@Column(name="ENG_DOCUMENT_DELETED")
	private String eng_document_deleted;
	
	
	@Column(name="CREATED_DATE")
	private Date created_date;
	
	@Column(name="CREATED_BY")
	private String created_by;
	
	
	@Column(name="UPDATED_DATE")
	private Date updated_date;
	
	@Column(name="UPDATED_BY")
	private String updated_by;

	public Employee_Engineer_doc() {
		super();
	}

	public Employee_Engineer_doc(String id, String employee_id, byte[] eng_resume, String engResumeName,
			byte[] eng_photo, String engPhotoName, byte[] eng_qualification, String engNameQualifi, byte[] eng_adhar,
			String engAdharName, String eng_document_deleted, Date created_date, String created_by, Date updated_date,
			String updated_by) {
		super();
		this.id = id;
		this.employee_id = employee_id;
		this.eng_resume = eng_resume;
		this.engResumeName = engResumeName;
		this.eng_photo = eng_photo;
		this.engPhotoName = engPhotoName;
		this.eng_qualification = eng_qualification;
		this.engNameQualifi = engNameQualifi;
		this.eng_adhar = eng_adhar;
		this.engAdharName = engAdharName;
		this.eng_document_deleted = eng_document_deleted;
		this.created_date = created_date;
		this.created_by = created_by;
		this.updated_date = updated_date;
		this.updated_by = updated_by;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getEmployee_id() {
		return employee_id;
	}

	public void setEmployee_id(String employee_id) {
		this.employee_id = employee_id;
	}

	public byte[] getEng_resume() {
		return eng_resume;
	}

	public void setEng_resume(byte[] eng_resume) {
		this.eng_resume = eng_resume;
	}

	public String getEngResumeName() {
		return engResumeName;
	}

	public void setEngResumeName(String engResumeName) {
		this.engResumeName = engResumeName;
	}

	public byte[] getEng_photo() {
		return eng_photo;
	}

	public void setEng_photo(byte[] eng_photo) {
		this.eng_photo = eng_photo;
	}

	public String getEngPhotoName() {
		return engPhotoName;
	}

	public void setEngPhotoName(String engPhotoName) {
		this.engPhotoName = engPhotoName;
	}

	public byte[] getEng_qualification() {
		return eng_qualification;
	}

	public void setEng_qualification(byte[] eng_qualification) {
		this.eng_qualification = eng_qualification;
	}

	public String getEngNameQualifi() {
		return engNameQualifi;
	}

	public void setEngNameQualifi(String engNameQualifi) {
		this.engNameQualifi = engNameQualifi;
	}

	public byte[] getEng_adhar() {
		return eng_adhar;
	}

	public void setEng_adhar(byte[] eng_adhar) {
		this.eng_adhar = eng_adhar;
	}

	public String getEngAdharName() {
		return engAdharName;
	}

	public void setEngAdharName(String engAdharName) {
		this.engAdharName = engAdharName;
	}

	public String getEng_document_deleted() {
		return eng_document_deleted;
	}

	public void setEng_document_deleted(String eng_document_deleted) {
		this.eng_document_deleted = eng_document_deleted;
	}

	public Date getCreated_date() {
		return created_date;
	}

	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}

	public String getCreated_by() {
		return created_by;
	}

	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}

	public Date getUpdated_date() {
		return updated_date;
	}

	public void setUpdated_date(Date updated_date) {
		this.updated_date = updated_date;
	}

	public String getUpdated_by() {
		return updated_by;
	}

	public void setUpdated_by(String updated_by) {
		this.updated_by = updated_by;
	}

	@Override
	public String toString() {
		return "Employee_Engineer_doc [id=" + id + ", employee_id=" + employee_id + ", eng_resume="
				+ Arrays.toString(eng_resume) + ", engResumeName=" + engResumeName + ", eng_photo="
				+ Arrays.toString(eng_photo) + ", engPhotoName=" + engPhotoName + ", eng_qualification="
				+ Arrays.toString(eng_qualification) + ", engNameQualifi=" + engNameQualifi + ", eng_adhar="
				+ Arrays.toString(eng_adhar) + ", engAdharName=" + engAdharName + ", eng_document_deleted="
				+ eng_document_deleted + ", created_date=" + created_date + ", created_by=" + created_by
				+ ", updated_date=" + updated_date + ", updated_by=" + updated_by + "]";
	}

	
	}
