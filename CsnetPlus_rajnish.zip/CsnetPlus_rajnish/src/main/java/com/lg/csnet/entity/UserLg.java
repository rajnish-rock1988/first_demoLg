package com.lg.csnet.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name = "Lg_User")
public class UserLg {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "Id")
	private Long id;
	
	
	@Column(name = "login_Id")
	private String loginId;

	@Column(name = "First_Name")
	private String firstName;

	@Column(name = "Last_Name")
	private String lastName;

	@Column(name = "Date_Of_Birth")
	private String DateBirth;

	@Column(name = "Telephone_No")
	private String Telphoneno;

	@Column(name = "Mobile_No")
	private String MobNum;

	@Column(name = "Address1")
	private String address1;

	@Column(name = "Address2")
	private String address2;

	@Column(name = "Email")
	private String email;

	@Column(name = "Zip_Code")
	private int zipCode;

	@Column(name = "State")
	private String state;

	@Column(name = "City")
	private String city;

	@Column(name = "User_Group")
	private String UserGroup;

	@Column(name = "Asc_Type")
	private String AscType;

	@Column(name = "Company")
	private String company;

	@Column(name = "Role")
	private String Role;

	@Column(name = "IpAddress")
	private String ipAddress;

	@Column(name = "createdDate")
	private Date createdDate;

	@Column(name = "createdBy")
	private String createdBy;
	
	@Column(name="password")
	private String password;
	
	
	
	
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getLoginId() {
		return loginId;
	}

	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getDateBirth() {
		return DateBirth;
	}

	public void setDateBirth(String dateBirth) {
		DateBirth = dateBirth;
	}

	public String getTelphoneno() {
		return Telphoneno;
	}

	public void setTelphoneno(String telphoneno) {
		Telphoneno = telphoneno;
	}

	public String getMobNum() {
		return MobNum;
	}

	public void setMobNum(String mobNum) {
		MobNum = mobNum;
	}

	public String getAddress1() {
		return address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getZipCode() {
		return zipCode;
	}

	public void setZipCode(int zipCode) {
		this.zipCode = zipCode;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getUserGroup() {
		return UserGroup;
	}

	public void setUserGroup(String userGroup) {
		UserGroup = userGroup;
	}

	public String getAscType() {
		return AscType;
	}

	public void setAscType(String ascType) {
		AscType = ascType;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getRole() {
		return Role;
	}

	public void setRole(String role) {
		Role = role;
	}

	public UserLg(Long id, String loginId, String firstName, String lastName, String dateBirth, String telphoneno,
			String mobNum, String address1, String address2, String email, int zipCode, String state, String city,
			String userGroup, String ascType, String company, String role, String ipAddress, Date createdDate,
			String createdBy) {
		super();
		this.id = id;
		this.loginId = loginId;
		this.firstName = firstName;
		this.lastName = lastName;
		DateBirth = dateBirth;
		Telphoneno = telphoneno;
		MobNum = mobNum;
		this.address1 = address1;
		this.address2 = address2;
		this.email = email;
		this.zipCode = zipCode;
		this.state = state;
		this.city = city;
		UserGroup = userGroup;
		AscType = ascType;
		this.company = company;
		Role = role;
		this.ipAddress = ipAddress;
		this.createdDate = createdDate;
		this.createdBy = createdBy;
	}

	@Override
	public String toString() {
		return "UserLg [id=" + id + ", loginId=" + loginId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", DateBirth=" + DateBirth + ", Telphoneno=" + Telphoneno + ", MobNum=" + MobNum + ", address1="
				+ address1 + ", address2=" + address2 + ", email=" + email + ", zipCode=" + zipCode + ", state=" + state
				+ ", city=" + city + ", UserGroup=" + UserGroup + ", AscType=" + AscType + ", company=" + company
				+ ", Role=" + Role + ", ipAddress=" + ipAddress + ", createdDate=" + createdDate + ", createdBy="
				+ createdBy + "]";
	}

	
	public UserLg() {
		super();

	}

}
