package com.lg.csnet.controller;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.lg.csnet.entity.MasterEntry;

import com.lg.csnet.repository.MainMasterRepository;
import com.lg.csnet.service.MainMasterService;

@Controller
public class MainMasterController {
	
	@Autowired
	private MainMasterRepository mainMasterRepository;
	
	@Autowired
	private MainMasterService mainMasterService;
	
	
	@GetMapping("/mainMaster")
	public String mainMaster(Model model,HttpServletRequest request) {
		
		System.out.println("main master........");
		return "mainMaster";
		
	}
	// this code is used directly connected with repository i.e; tight coupled connection
	@PostMapping("/submitMainMaster")
	public String mainMasterSubmit(Model model, HttpServletRequest request, @ModelAttribute MasterEntry masterEntry) {
		
		System.out.println("create Master......");
		mainMasterRepository.save(masterEntry);
		return "mainMaster";
		
	}
	
	// this  ode is used loosely coupled using service class 
	@PostMapping("/saveMaster")
	public String saveMasterEntry(@ModelAttribute MasterEntry masterEntry, HttpServletRequest request,Model model) {

		System.out.println("save data starts...........");

		System.out.println(masterEntry);

		System.out.println("UserMaster Saved Successfully");
		
		String createdBy = "priyanka";	
		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		String strDate = formatter.format(date);
		System.out.println(strDate);
		
		
		masterEntry.setCreatedBy(createdBy);
		masterEntry.setCreatedOn(date);
		
		
		
		String ipAdd = "";
		InetAddress localHost = null;
		try {
		//	localHost = InetAddress.getLocalHost();
		//	ipAdd = localHost.getHostAddress();
		//	masterEntry.setIpAddress(ipAdd);
			//String ipAddress = masterEntry.getIpAddress();
			//System.out.println("ipAddress is" + ipAddress);
			
			System.out.println(
					"localHost-------" + localHost.getHostAddress() + "\n\n name---" + localHost.getHostName());
			mainMasterService.saveMaster(masterEntry);
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
			
	
		
		return "mainMaster";

 }
}
