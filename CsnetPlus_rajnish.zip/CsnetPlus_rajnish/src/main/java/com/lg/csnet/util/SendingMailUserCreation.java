package com.lg.csnet.util;

import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class SendingMailUserCreation {
	//variable for Email
			@Value("${CreatUserPassword.mail.smtp.host}") //CreatUserPassword.mail.smtp.host
			String host;
			@Value("${CreatUserPassword.mail.smtp.port}")
			String port;
			@Value("${CreatUserPassword.mail.smtp.ssl.enable}")
			String enable;
			@Value("${CreatUserPassword.mail.smtp.auth}")
			String auth;
			@Value("${CreatUserPassword.mail.Sender.SystemGeneratePassword}")
			String senderMailPassword;
			
			@Value("${test.priyanka}")
			String priyanka;
			
			@Value("${test.intdata}")
			Integer intdata;
			
	
	public void sendPasswordEmail(String subject,String message, String receiverMail, String SenderMail ,String ccmail) {
		
		//get the System properties
		Properties properties = System.getProperties();
		System.out.println("Properties : "+properties);
		
		System.out.println("test.priyanka-->"+priyanka);
		System.out.println("test.intdata-->"+intdata);
		//host set
		properties.put("mail.smtp.host", host);//7778
		properties.put("mail.smtp.port", port);//995
		properties.put("mail.smtp.ssl.enable",enable);//abcd
		properties.put("mail.smtp.auth",auth);//678
		
		//step 1: to get the session object
		Session session = Session.getInstance(properties, new Authenticator() {
		
			@Override
			protected PasswordAuthentication getPasswordAuthentication() {
				
				return new PasswordAuthentication(SenderMail,senderMailPassword);
			}

		});
		//to enable Debug in mail make below .setDebug(true)
		session.setDebug(true);
		//step 2: Compose Message
		MimeMessage mimeMessage = new MimeMessage(session);
		
		try {
			//from email
			mimeMessage.setFrom(SenderMail);
			
			//adding recipient to message
			mimeMessage.addRecipient(Message.RecipientType.TO, new InternetAddress(receiverMail));
			
			//adding cc mail
			mimeMessage.addRecipient(Message.RecipientType.CC, new InternetAddress(ccmail));
			
			//adding subject to message
			mimeMessage.setSubject(subject);
			
			//adding text to message
			mimeMessage.setText(message);
			
			//send
			
		//Step 3 : send the Message using Transport class
			Transport.send(mimeMessage);
			
			System.out.println("Send Success \n" );
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("getting exception while sending email----"+e);
		}
		
	}

}
