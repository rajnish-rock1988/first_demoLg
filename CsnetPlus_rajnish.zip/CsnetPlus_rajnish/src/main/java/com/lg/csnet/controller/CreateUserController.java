package com.lg.csnet.controller;

import java.net.InetAddress;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.lg.csnet.entity.UserLg;
import com.lg.csnet.repository.UserLifeRepository;
import com.lg.csnet.service.UserLifeService;
import com.lg.csnet.util.SendingMailUserCreation;

@Controller
public class CreateUserController {
	
	@Value("${CreatUserPassword.mail.Sender.subject}")
	String subject;
	
	@Value("${CreatUserPassword.mail.Sender.SenderMail}")
	String SenderMail;
	
	@Autowired
	private SendingMailUserCreation sendingMailUserCreation;
	

	@Autowired
	private UserLifeRepository userLifeRepository;

	@Autowired
	private UserLifeService userLifeService;

	// only view the createUser html page on server

	@GetMapping("/createUser")
	public String CreateUser(Model model, HttpServletRequest request) {

		System.out.println("Create User1");

		return "createUser";
	}

	// after the html page open then submit the page on server

	@PostMapping("/createUserSubmit")
	public String CreateUserSubmit(Model model, HttpServletRequest request, @ModelAttribute UserLg userLg) {

		System.out.println("create User2---------");
		System.out.println("UserLg" + userLg);

		userLifeRepository.save(userLg);
		return "createUser";

	}

	// saving all the data

	@PostMapping("/saveUser")
	public String saveUserLg(@ModelAttribute UserLg userlg, HttpServletRequest request,Model model) {

		System.out.println("save data starts...........");

		

		System.out.println(userlg);

		System.out.println("User Saved Successfully");

		// saving creation date
		String createdBy = "priyanka";
		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		String strDate = formatter.format(date);
		System.out.println(strDate);
		
		
		userlg.setCreatedBy(createdBy);
		userlg.setCreatedDate(date);

		// saving Ipaddress
		
		String loginId = request.getParameter("loginId");
		String ipAdd = "";
		
		try {
			/*
			 * InetAddress localHost = InetAddress.getLocalHost(); ipAdd =
			 * localHost.getHostAddress(); userlg.setIpAddress(ipAdd); System.out.println(
			 * "localHost-------" + localHost.getHostAddress() + "\n\n name---" +
			 * localHost.getHostName());
			 */
		} catch (Exception e) {
			System.out.println("Exception for generating --" + e);
		}
		userLifeRepository.addIpaddForUserCreation(loginId, ipAdd);// updating or saving ip add or other thing
		System.out.println("ip address save successfully---");

		// ------------------generate any random no
		Random random = new Random();
		String s1 = String.format("%04d", random.nextInt(10000));
		System.out.println("Random number......" + s1);
		String password = "CSNET" + s1;
		userlg.setPassword(password);
		System.out.println("password is ......" + password);
		String userRecieverEmail = request.getParameter("email");
		

		// sending mail while user creation

		String mailmessage = "This is your lg project user creation mail" + " " + "\n\n loginId \t" + loginId
				+ "\npassword---" + password;
		System.out.println("userReceiverEmail is" + userRecieverEmail);
	
		//CHECKING DUP LOGIN ID
		List<String> findByDupLoginId = userLifeRepository.findByDupLoginId(loginId);
		System.out.println("findByDupLoginId-->"+ findByDupLoginId);
		if(findByDupLoginId.size()==0) {
			userLifeService.saveUser(userlg); // saving all data
		}else {
			model.addAttribute("error","you can't creae user due to duplicate login Id!");
		}
		
		
	
		
	
	  //SendingMailUserCreation sendingMailUserCreation2 = new SendingMailUserCreation();
		String ccmail="rajnish.4632@gmail.com";
	//  sendingMailUserCreation.sendPasswordEmail(subject, mailmessage, userRecieverEmail, SenderMail,ccmail);
		
		
		
		return "createUser";

	}

}
