package com.lg.csnet.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.lg.csnet.entity.MasterEntry;

public interface MainMasterRepository extends JpaRepository<MasterEntry, Long>{

	/*
	 * @Query( value = "SELECT * FROM master_entry WHERE id=:id", nativeQuery =
	 * true) // search MasterEntry List<MasterEntry> findById(long id);
	 */

	//@Query( value = "SELECT * FROM master_entry WHERE id=:id", nativeQuery = true)
	List<MasterEntry> findById(long id);



	
	
	//@Query( value = "SELECT * FROM lg_user WHERE login_id=:loginId", nativeQuery = true)
	  @Query( value = "SELECT * FROM MASTER_ENTRY WHERE LOOKUP_CODE=:lookupCode OR LOOKUP_TYPE=:lookupType AND VALUE=:value",nativeQuery = true)
	  List<MasterEntry> searchData(String lookupCode,String lookupType,String value);
	//	List<MasterEntry> searchData(Long lookupCode, String lookupType);
	 
		
	
	

	

}
