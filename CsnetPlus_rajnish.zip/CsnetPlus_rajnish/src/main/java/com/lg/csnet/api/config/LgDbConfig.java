package com.lg.csnet.api.config;




public class LgDbConfig {

}
