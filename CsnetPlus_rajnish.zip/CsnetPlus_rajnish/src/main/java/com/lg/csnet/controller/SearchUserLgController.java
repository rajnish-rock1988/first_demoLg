package com.lg.csnet.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.lg.csnet.entity.UserLg;
import com.lg.csnet.repository.UserLifeRepository;

@Controller
public class SearchUserLgController {

	@Autowired
	private UserLifeRepository userLifeRepository;

	@GetMapping("/searchUser")
	public String searchUserLg(Model model, HttpServletRequest request) {
		System.out.println("search user page.......");

		return "searchUser";

	}

	@PostMapping("/searchUserId")
	public String searchUserLg(HttpServletRequest request, ModelMap model) {

		String loginId = request.getParameter("loginId");
		System.out.println("LoginId is" + loginId);

		List<UserLg> findByLoginIdResult = userLifeRepository.findById(loginId);

		System.out.println("Getting all data using search" + findByLoginIdResult);

		if (loginId != null) {

			model.addAttribute("loginId", findByLoginIdResult);
			return "searchUser";

		} else {
			System.out.println("error searching data loginId");
		}

		return "searchUser";

	}

}
