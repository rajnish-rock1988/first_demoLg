package com.lg.csnet.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="CSN_CODE_MASTER")
public class CsnCodeMaster {

	@Id
	@Column(name="SPID")
	private long spid;
	
	@Column(name="LOOKUP_CODE")
	private long lookupCode;
	
	@Column(name="LOOKUP_TYPE")
	private String lookupType;
	
	@Column(name="VALUE")
	private String value;
	
	@Column(name="DESCRIPTION")
	private String description;
	
	@Column(name="PARENT_LOOKUP_CODE")
	private int parentLookupCode;
	
	@Column(name="PARENT_LOOKUP_TYPE")
	private String parentLookupType;
	
	@Column(name="VALID_FROM")
	private Date validFrom;
	
	@Column(name="VALID_TO")
	private Date validTo;
	
	@Column(name="DELETE_FLAG")
	private String deleteFlag;
	
	@Column(name="CREATED_BY")
	private String createdBy;
	
	@Column(name="CREATED_ON")
	private Date createdOn;
	
	@Column(name="MODIFIED_BY")
	private String modifiedBy;
	
	@Column(name="MODIFY_ON")
	private Date modifiedOn;

	public CsnCodeMaster() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CsnCodeMaster(long spid, long lookupCode, String lookupType, String value, String description,
			int parentLookupCode, String parentLookupType, Date validFrom, Date validTo, String deleteFlag,
			String createdBy, Date createdOn, String modifiedBy, Date modifiedOn) {
		super();
		this.spid = spid;
		this.lookupCode = lookupCode;
		this.lookupType = lookupType;
		this.value = value;
		this.description = description;
		this.parentLookupCode = parentLookupCode;
		this.parentLookupType = parentLookupType;
		this.validFrom = validFrom;
		this.validTo = validTo;
		this.deleteFlag = deleteFlag;
		this.createdBy = createdBy;
		this.createdOn = createdOn;
		this.modifiedBy = modifiedBy;
		this.modifiedOn = modifiedOn;
	}

	public long getSpid() {
		return spid;
	}

	public void setSpid(long spid) {
		this.spid = spid;
	}

	public long getLookupCode() {
		return lookupCode;
	}

	public void setLookupCode(long lookupCode) {
		this.lookupCode = lookupCode;
	}

	public String getLookupType() {
		return lookupType;
	}

	public void setLookupType(String lookupType) {
		this.lookupType = lookupType;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getParentLookupCode() {
		return parentLookupCode;
	}

	public void setParentLookupCode(int parentLookupCode) {
		this.parentLookupCode = parentLookupCode;
	}

	public String getParentLookupType() {
		return parentLookupType;
	}

	public void setParentLookupType(String parentLookupType) {
		this.parentLookupType = parentLookupType;
	}

	public Date getValidFrom() {
		return validFrom;
	}

	public void setValidFrom(Date validFrom) {
		this.validFrom = validFrom;
	}

	public Date getValidTo() {
		return validTo;
	}

	public void setValidTo(Date validTo) {
		this.validTo = validTo;
	}

	public String getDeleteFlag() {
		return deleteFlag;
	}

	public void setDeleteFlag(String deleteFlag) {
		this.deleteFlag = deleteFlag;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	@Override
	public String toString() {
		return "CsnCodeMaster [spid=" + spid + ", lookupCode=" + lookupCode + ", lookupType=" + lookupType + ", value="
				+ value + ", description=" + description + ", parentLookupCode=" + parentLookupCode
				+ ", parentLookupType=" + parentLookupType + ", validFrom=" + validFrom + ", validTo=" + validTo
				+ ", deleteFlag=" + deleteFlag + ", createdBy=" + createdBy + ", createdOn=" + createdOn
				+ ", modifiedBy=" + modifiedBy + ", modifiedOn=" + modifiedOn + "]";
	}
	
	
}
