package com.lg.csnet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CsnetPlusApplicationTests {

	@Test
	void contextLoads() {
	}

}
